</main>

<!-- FLOATING WHATSAPP — único botão CTA principal -->
<a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>"
   class="whatsapp-float"
   target="_blank" rel="noopener noreferrer"
   aria-label="Solicitar segunda via pelo WhatsApp"
   title="Solicitar segunda via — WhatsApp">
  <svg width="28" height="28" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
  <span>Solicitar Segunda Via</span>
</a>

<footer class="site-footer">
  <div class="container">
    <div class="footer-hours-bar">
      <strong>Atendimento:</strong> <?php echo BUSINESS_HOURS_TEXT; ?>
      &nbsp;&bull;&nbsp; <strong>Cobertura:</strong> Todo o Brasil
    </div>
    <div class="footer-grid">
      <div class="footer-col">
        <h3><?php echo SITE_NAME; ?></h3>
        <p>Portal informativo e de orientação para beneficiários Unimed. Ajudamos você a emitir a segunda via do boleto de forma rápida e sem complicação.</p>
        <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>"
           class="btn-whatsapp-footer" target="_blank" rel="noopener noreferrer">
          <svg width="17" height="17" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
          Falar pelo WhatsApp
        </a>
      </div>
      <div class="footer-col">
        <h3>Links Úteis</h3>
        <ul class="footer-links">
          <li><a href="/#">Início</a></li>
          <li><a href="/segunda-via.php">Segunda Via de Boleto</a></li>
          <li><a href="/faq.php">Dúvidas Frequentes</a></li>
          <li><a href="/blog/">Blog Informativo</a></li>
          <li><a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>" target="_blank" rel="noopener noreferrer">Portal Oficial Unimed &#8599;</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h3>Informações</h3>
        <ul class="footer-links">
          <li><a href="/sobre.php">Sobre Nós</a></li>
          <li><a href="/contato.php">Contato</a></li>
          <li><a href="/politica-de-privacidade.php">Política de Privacidade</a></li>
          <li><a href="/termos-de-uso.php">Termos de Uso</a></li>
        </ul>
        <div class="footer-contact-block">
          <p><strong>Horário:</strong><br><?php echo BUSINESS_HOURS_TEXT; ?></p>
          <p><strong>E-mail:</strong><br><a href="mailto:<?php echo CONTACT_EMAIL; ?>" style="color:inherit;"><?php echo CONTACT_EMAIL; ?></a></p>
          <p style="font-size:.8rem;color:var(--gray-600);margin-top:6px;line-height:1.5;"><?php echo defined('CONTACT_ADDRESS') ? CONTACT_ADDRESS : ''; ?></p>
        </div>
      </div>
      </div>
    <div class="footer-bottom">
      <p>&copy; <?php echo (FOUNDED_YEAR < date('Y')) ? FOUNDED_YEAR . '–' . date('Y') : date('Y'); ?> <?php echo SITE_NAME; ?>. Todos os direitos reservados.</p>
      <p class="footer-bottom-links">
        <a href="/politica-de-privacidade.php">Privacidade</a> &middot;
        <a href="/termos-de-uso.php">Termos</a>
      </p>
    </div>
  </div>
</footer>

<script src="/js/main.js"></script>
</body>
</html>
