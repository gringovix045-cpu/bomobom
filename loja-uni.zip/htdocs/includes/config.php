<?php
// ============================================================
// CONFIGURAÇÕES DO SITE — edite apenas este arquivo
// ============================================================

define('SITE_NAME',        'Boleto Unimed Fácil');
define('SITE_TAGLINE',     'Segunda Via de Boleto Unimed com Rapidez e Segurança');
define('SITE_URL',         'https://www.seusite.com.br'); // sem barra final
define('SITE_DESCRIPTION', 'Portal independente de atendimento para emissão de segunda via de boleto Unimed. Tire suas dúvidas e solicite seu boleto de forma rápida e segura.');

// Keywords (para meta tag keywords + SEO)
define('SITE_KEYWORDS', 'segunda via boleto unimed, boleto unimed vencido, emitir segunda via unimed, segunda via unimed pelo celular, como pagar boleto unimed, boleto unimed atualizado');

// WhatsApp — coloque apenas números, sem +, espaço ou traço
define('WHATSAPP_NUMBER',  '5511999999999');
define('WHATSAPP_MESSAGE', 'Olá! Preciso de ajuda com a segunda via do meu boleto Unimed.');

// E-mail de contato
define('CONTACT_EMAIL',    'atendimento@canalunimevirtual.site');

// Endereço físico
define('CONTACT_ADDRESS', 'Rua Aquilina Bonatti Malavazzi, B - MALAVAZZI, 105 - Jardim Vista Alegre, Paulínia - SP, 13140-188');

// Ano de fundação (para o footer)
define('FOUNDED_YEAR',     '2024');

// Horário de atendimento
define('BUSINESS_HOURS_TEXT',   'Seg a Sex: 8h às 20h');
define('BUSINESS_HOURS_SCHEMA', 'Mo-Fr 08:00-20:00');

// Cobertura geográfica — lista de cidades/estados mais buscados no nicho
define('AREA_SERVED', 'São Paulo, Rio de Janeiro, Minas Gerais, Paraná, Santa Catarina, Rio Grande do Sul, Bahia, Pernambuco, Ceará, Goiás');

// Imagem para Open Graph (coloque uma imagem real em /images/og-image.jpg)
// Tamanho recomendado: 1200x630px
define('OG_IMAGE_URL', SITE_URL . '/images/og-image.jpg');

// Google Analytics ID (deixe vazio para desativar)
define('GA_ID', '');

// Google Search Console — meta de verificação
// Exemplo: 'XXXXXXXXXX' (apenas o código, sem as aspas da propriedade)
define('GSC_VERIFY_CODE', '');

// Disclaimer que aparece no footer e em avisos
define('DISCLAIMER', 'Este portal é um serviço independente de orientação e atendimento ao beneficiário Unimed. Não somos a operadora Unimed e não temos vínculo institucional com ela. As informações aqui prestadas têm caráter informativo e de suporte ao cliente.');
define('DISCLAIMER_SHORT', 'Portal independente. Não é o site oficial da Unimed.');
