<?php
require_once __DIR__ . '/config.php';
$current_page = basename($_SERVER['PHP_SELF'], '.php');
$canonical    = SITE_URL . strtok($_SERVER['REQUEST_URI'], '?');
$og_image     = OG_IMAGE_URL;
$is_home      = ($current_page === 'index' || $_SERVER['REQUEST_URI'] === '/');
$is_blog      = strpos($_SERVER['REQUEST_URI'], '/blog') !== false;

$wa_url = 'https://wa.me/' . WHATSAPP_NUMBER . '?text=' . urlencode(WHATSAPP_MESSAGE);

$breadcrumb_schema = '';
if (isset($breadcrumbs) && is_array($breadcrumbs)) {
    $items = [];
    foreach ($breadcrumbs as $pos => $crumb) {
        $items[] = '{"@type":"ListItem","position":' . ($pos+1) . ',"name":"' . htmlspecialchars($crumb['name']) . '","item":"' . htmlspecialchars($crumb['url']) . '"}';
    }
    $breadcrumb_schema = '<script type="application/ld+json">{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[' . implode(',', $items) . ']}</script>';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' | ' . SITE_NAME : SITE_NAME . ' — ' . SITE_TAGLINE; ?></title>
  <meta name="description" content="<?php echo isset($page_description) ? htmlspecialchars($page_description) : SITE_DESCRIPTION; ?>">
  <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">
  <meta name="author" content="<?php echo SITE_NAME; ?>">
  <link rel="canonical" href="<?php echo htmlspecialchars($canonical); ?>">
  <?php if (!empty(GSC_VERIFY_CODE)): ?><meta name="google-site-verification" content="<?php echo GSC_VERIFY_CODE; ?>"><?php endif; ?>
  <link rel="icon" type="image/x-icon" href="/favicon.ico">
  <link rel="apple-touch-icon" sizes="180x180" href="/images/apple-touch-icon.png">
  <meta property="og:type" content="<?php echo $is_home ? 'website' : 'article'; ?>">
  <meta property="og:site_name" content="<?php echo SITE_NAME; ?>">
  <meta property="og:title" content="<?php echo isset($page_title) ? htmlspecialchars($page_title) : SITE_NAME . ' — ' . SITE_TAGLINE; ?>">
  <meta property="og:description" content="<?php echo isset($page_description) ? htmlspecialchars($page_description) : SITE_DESCRIPTION; ?>">
  <meta property="og:url" content="<?php echo htmlspecialchars($canonical); ?>">
  <meta property="og:image" content="<?php echo $og_image; ?>">
  <meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
  <meta property="og:locale" content="pt_BR">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo isset($page_title) ? htmlspecialchars($page_title) : SITE_NAME; ?>">
  <meta name="twitter:description" content="<?php echo isset($page_description) ? htmlspecialchars($page_description) : SITE_DESCRIPTION; ?>">
  <meta name="twitter:image" content="<?php echo $og_image; ?>">
  <?php if ($is_home): ?>
  <script type="application/ld+json">{"@context":"https://schema.org","@graph":[
    {"@type":"WebSite","@id":"<?php echo SITE_URL; ?>/#website","url":"<?php echo SITE_URL; ?>/","name":"<?php echo SITE_NAME; ?>","inLanguage":"pt-BR"},
    {"@type":"Organization","@id":"<?php echo SITE_URL; ?>/#org","name":"<?php echo SITE_NAME; ?>","url":"<?php echo SITE_URL; ?>/","email":"<?php echo CONTACT_EMAIL; ?>"},
    {"@type":"LocalBusiness","name":"<?php echo SITE_NAME; ?>","url":"<?php echo SITE_URL; ?>/","email":"<?php echo CONTACT_EMAIL; ?>","openingHours":"<?php echo BUSINESS_HOURS_SCHEMA; ?>","areaServed":"<?php echo AREA_SERVED; ?>","priceRange":"Gratuito"}
  ]}</script>
  <?php elseif (!isset($schema)): ?>
  <script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"<?php echo SITE_NAME; ?>","url":"<?php echo SITE_URL; ?>/"}</script>
  <?php else: echo $schema; endif; ?>
  <?php echo $breadcrumb_schema; ?>
  <?php if (!empty(GA_ID)): ?>
  <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo GA_ID; ?>"></script>
  <script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','<?php echo GA_ID; ?>',{'anonymize_ip':true});</script>
  <?php endif; ?>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<a class="skip-link" href="#main-content">Pular para o conteúdo</a>

<?php if (!$is_home): ?>
<div class="info-notice-bar" role="note">
  <div class="container info-notice-inner">
    <span class="info-notice-dot"></span>
    <span>Site informativo —</span>
    <a href="/">Acessar Portal do Cliente</a>
  </div>
</div>
<?php endif; ?>

<header class="site-header" role="banner">
  <div class="container header-inner">

    <a href="/" class="logo" aria-label="<?php echo SITE_NAME; ?> — Página inicial">
      <span class="logo-icon">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
      </span>
      <span class="logo-wordmark">
        <strong>Boleto Unimed</strong>
        <em>Fácil</em>
      </span>
    </a>

    <!-- Desktop nav — duas versões: homepage (âncoras internas) vs. páginas internas (→ homepage) -->
    <nav class="main-nav" aria-label="Navegação principal">
      <?php if ($is_home): ?>
        <a href="#o-que-e"       class="nav-link smooth-anchor">Segunda Via</a>
        <a href="#pagamentos"    class="nav-link smooth-anchor">Pagamentos</a>
        <a href="#atendimento-zap" class="nav-link smooth-anchor">Financeiro</a>
        <a href="#atendimento-zap" class="nav-link smooth-anchor">Atendimento</a>
        <a href="#faq"           class="nav-link smooth-anchor">FAQ</a>
        <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>"       class="nav-link nav-portal smooth-anchor">Portal do Cliente</a>
      <?php else: ?>
        <a href="/#o-que-e"       class="nav-link">Segunda Via</a>
        <a href="/#pagamentos"    class="nav-link">Pagamentos</a>
        <a href="/#atendimento-zap" class="nav-link">Financeiro</a>
        <a href="/#atendimento-zap" class="nav-link">Atendimento</a>
        <a href="/#faq"           class="nav-link">FAQ</a>
        <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>" class="nav-link nav-portal <?php echo ($current_page==='segunda-via')?'active':''; ?>">Portal do Cliente</a>
      <?php endif; ?>
    </nav>

    <button class="nav-toggle" id="nav-toggle" aria-label="Abrir menu" aria-expanded="false">
      <span class="ham-bar"></span>
      <span class="ham-bar"></span>
      <span class="ham-bar"></span>
    </button>

  </div>
</header>

<!-- MOBILE DRAWER — duas versões: homepage vs. páginas internas -->
<div class="mobile-overlay" id="mobile-overlay" role="dialog" aria-modal="true" aria-label="Menu de navegação">
  <div class="mobile-drawer" role="document">
    <div class="drawer-header">
      <span class="drawer-logo">Boleto Unimed Fácil</span>
      <button class="drawer-close" id="drawer-close" aria-label="Fechar menu">&times;</button>
    </div>
    <div class="drawer-links">
      <?php if ($is_home): ?>
        <a href="#o-que-e"         class="drawer-link drawer-anchor">Segunda Via</a>
        <a href="#pagamentos"      class="drawer-link drawer-anchor">Pagamentos</a>
        <a href="#atendimento-zap" class="drawer-link drawer-anchor">Financeiro</a>
        <a href="#atendimento-zap" class="drawer-link drawer-anchor">Atendimento</a>
        <a href="#faq"             class="drawer-link drawer-anchor">FAQ</a>
      <?php else: ?>
        <a href="/"                class="drawer-link">Segunda Via</a>
        <a href="/#pagamentos"     class="drawer-link">Pagamentos</a>
        <a href="/#atendimento-zap" class="drawer-link">Financeiro</a>
        <a href="/#atendimento-zap" class="drawer-link">Atendimento</a>
        <a href="/#faq"            class="drawer-link">FAQ</a>
      <?php endif; ?>
    </div>
    <div class="drawer-footer">
      <a href="<?php echo $wa_url; ?>" class="drawer-portal-btn" target="_blank" rel="noopener noreferrer">Emitir Segunda Via Agora</a>
    </div>
  </div>
</div>

<main id="main-content">
