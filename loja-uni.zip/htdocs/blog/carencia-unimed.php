<?php
require_once __DIR__ . '/../includes/config.php';
$page_title       = 'Carência na Unimed: Prazos, Exceções e Como Reduzir';
$page_description = 'Entenda tudo sobre carência na Unimed: quais são os prazos por procedimento, quando você pode usar o plano desde o primeiro dia e como reduzir a carência.';
$schema = '<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Carência na Unimed: Prazos, Exceções e Como Reduzir",
  "description": "Prazos de carência na Unimed por tipo de procedimento e como reduzir ou eliminar a carência.",
  "datePublished": "2025-04-20",
  "dateModified": "' . date('Y-m-d') . '",
  "author": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"},
  "publisher": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"}
}
</script>';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="article-header">
  <div class="container">
    <nav class="breadcrumb" aria-label="Breadcrumb">
      <a href="/">Início</a> ›
      <a href="/blog/">Blog</a> ›
      <span>Carência na Unimed</span>
    </nav>
    <h1>Carência na Unimed: Prazos, Exceções e Como Reduzir</h1>
    <div class="article-meta">
      <span>&#128197; 20 de abril de 2025</span>
      <span>&#128336; 5 minutos de leitura</span>
      <span>&#127991; Carência</span>
    </div>
  </div>
</div>

<div class="article-body">

  <p>A <strong>carência</strong> é um dos temas que mais gera dúvidas entre os beneficiários de plano de saúde. Afinal, ninguém quer contratar um plano e depois descobrir que não pode usar para um procedimento específico.</p>
  <p>Neste artigo, explicamos tudo sobre a carência na Unimed de forma clara e simples.</p>

  <h2>O que é carência?</h2>
  <p>Carência é o <strong>período de espera</strong> que começa na data de assinatura do contrato, durante o qual o beneficiário ainda não tem acesso a determinados serviços ou procedimentos do plano.</p>
  <p>A carência existe para proteger as operadoras de planos de saúde de pessoas que contratariam o plano apenas no momento em que precisassem de um procedimento caro. Esse período varia conforme o tipo de serviço.</p>

  <h2>Prazos de carência na Unimed (máximos permitidos pela ANS)</h2>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Tipo de serviço</th><th>Prazo máximo de carência</th></tr>
      </thead>
      <tbody>
        <tr><td>Urgência e emergência</td><td><strong>24 horas</strong></td></tr>
        <tr><td>Consultas médicas e exames simples</td><td><strong>30 dias</strong></td></tr>
        <tr><td>Partos a termo (40 semanas)</td><td><strong>300 dias</strong></td></tr>
        <tr><td>Demais internações (cirurgias eletivas, etc.)</td><td><strong>180 dias</strong></td></tr>
        <tr><td>Doenças preexistentes (com cobertura parcial)</td><td><strong>24 meses</strong></td></tr>
      </tbody>
    </table>
  </div>

  <div class="info-box">
    <strong>&#128161; Importante:</strong> Esses são os prazos <em>máximos</em> permitidos pela ANS. A Unimed pode oferecer prazos menores por política comercial. Verifique sempre o contrato do seu plano específico.
  </div>

  <h2>O que não tem carência?</h2>
  <p>A ANS garante que, independentemente da carência contratual, os beneficiários sempre têm direito a:</p>
  <ul>
    <li>Atendimento de <strong>urgência e emergência</strong> após 24 horas de contrato;</li>
    <li>Cobertura para complicações de procedimentos excluídos (ex.: complicação de cirurgia estética);</li>
    <li>Atendimento durante a carência quando já havia cobertura prévia em outro plano (portabilidade).</li>
  </ul>

  <h2>Doença preexistente: como funciona?</h2>
  <p>Uma <strong>doença ou lesão preexistente (DLP)</strong> é qualquer condição de saúde que você já tinha antes de contratar o plano. Para essas condições, o plano pode:</p>
  <ul>
    <li>Aguardar o cumprimento da carência normal (até 24 meses para procedimentos de alta complexidade);</li>
    <li>Oferecer <strong>Cobertura Parcial Temporária (CPT)</strong>: cobertura com exclusão de procedimentos de alta complexidade relacionados à doença, por no máximo 24 meses.</li>
  </ul>
  <p>Após 24 meses de contrato, <strong>nenhuma exclusão pode ser mantida</strong> com base em DLP, por determinação da ANS.</p>

  <h2>Como reduzir ou eliminar a carência?</h2>
  <p>Existem algumas formas de reduzir ou zerar a carência:</p>

  <h3>Portabilidade de carências</h3>
  <p>Se você tinha um plano de saúde anterior e ficou <strong>no máximo 30 dias</strong> sem cobertura entre os dois planos, você pode solicitar a portabilidade das carências já cumpridas. Com isso, as carências que já foram cumpridas no plano anterior são aproveitadas no novo plano.</p>

  <h3>Planos coletivos empresariais</h3>
  <p>Muitos planos coletivos por adesão ou empresariais possuem <strong>prazos de carência reduzidos</strong> ou até carência zero, dependendo do acordo entre a empresa e a Unimed.</p>

  <h3>Negociação na contratação</h3>
  <p>Em alguns casos, especialmente em planos coletivos com grande volume de beneficiários, pode ser possível negociar a redução dos prazos de carência.</p>

  <div class="article-cta">
    <h3>Precisa de ajuda com seu boleto?</h3>
    <p>Acesse o portal do cliente Unimed e resolva online de forma rápida e segura.</p>
    <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>" class="btn btn-whatsapp btn-lg" target="_blank" rel="noopener noreferrer">Solicitar Segunda Via</a>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
