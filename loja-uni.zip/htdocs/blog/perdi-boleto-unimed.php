<?php
require_once __DIR__ . '/../includes/config.php';
$page_title       = 'Perdi o Boleto Unimed: o que fazer agora?';
$page_description = 'Perdeu o boleto do plano Unimed? Veja o que fazer, onde solicitar a segunda via e como pagar sem perder a cobertura do plano.';
$schema = '<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Perdi o Boleto Unimed: o que fazer agora?",
  "description": "Perdeu o boleto do plano Unimed? Veja o que fazer, onde solicitar a segunda via e como pagar sem perder a cobertura.",
  "datePublished": "2025-05-20",
  "dateModified": "' . date('Y-m-d') . '",
  "author": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"},
  "publisher": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"}
}
</script>';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="article-header">
  <div class="container">
    <nav class="breadcrumb" aria-label="Breadcrumb">
      <a href="/">Início</a> ›
      <a href="/blog/">Blog</a> ›
      <span>Perdi o Boleto Unimed</span>
    </nav>
    <h1>Perdi o Boleto Unimed: o que fazer agora?</h1>
    <div class="article-meta">
      <span>&#128197; 20 de maio de 2025</span>
      <span>&#128336; 3 minutos de leitura</span>
      <span>&#127991; Dúvidas</span>
    </div>
  </div>
</div>

<div class="article-body">

  <p>Perdeu o boleto do plano Unimed e não sabe o que fazer? Fique tranquilo — isso acontece com muita frequência e tem solução simples. Neste artigo, vamos te mostrar exatamente o que fazer.</p>

  <div class="info-box">
    <strong>&#128338; Resolução rápida:</strong> Perdeu o boleto? Solicite a segunda via agora pelo nosso WhatsApp. Informe seu nome e CPF e receba o novo boleto em minutos.
  </div>

  <h2>Por que as pessoas perdem o boleto Unimed?</h2>
  <p>Existem várias razões pelas quais um beneficiário pode não ter o boleto em mãos:</p>
  <ul>
    <li>O boleto físico foi extraviado nos Correios;</li>
    <li>O e-mail com o boleto foi para a pasta de spam ou lixo eletrônico;</li>
    <li>O e-mail cadastrado está desatualizado;</li>
    <li>Você está com um novo endereço e não atualizou o cadastro;</li>
    <li>O boleto foi acidentalmente descartado;</li>
    <li>Você está gerenciando o plano de outra pessoa (pai, mãe, familiar).</li>
  </ul>

  <h2>O que fazer quando você perde o boleto Unimed</h2>
  <p>A solução é simples: solicitar a <strong>segunda via do boleto</strong>. Veja as opções:</p>

  <h3>Opção 1 — Pelo nosso WhatsApp (mais rápido)</h3>
  <p>Clique no botão de WhatsApp nesta página, informe seu nome completo e CPF, e nossa equipe envia o boleto atualizado em minutos. Simples assim!</p>

  <h3>Opção 2 — Pelo portal do beneficiário</h3>
  <p>Acesse o site da sua cooperativa Unimed, faça login e acesse a área de boletos ou financeiro. Se não tem cadastro, pode ser necessário criar um.</p>

  <h3>Opção 3 — Pelo aplicativo da Unimed</h3>
  <p>Se sua cooperativa tem app (disponível na App Store e Google Play), você pode acessar os boletos diretamente pelo celular.</p>

  <h3>Opção 4 — Pelo telefone</h3>
  <p>Ligue para a central de atendimento da sua regional Unimed e solicite o envio do boleto por e-mail ou WhatsApp.</p>

  <h2>Preciso de algum documento para solicitar a segunda via?</h2>
  <p>Sim. Para solicitar a segunda via, você precisará de:</p>
  <ul>
    <li><strong>Nome completo</strong> do titular do plano;</li>
    <li><strong>CPF</strong> do titular;</li>
    <li>Em alguns casos: data de nascimento ou número do contrato.</li>
  </ul>

  <h2>E se o boleto ainda não tiver vencido?</h2>
  <p>Ótimo! Solicite a segunda via normalmente — ela terá exatamente o mesmo valor do original, sem nenhum acréscimo de juros ou multa.</p>

  <h2>E se o boleto já tiver vencido?</h2>
  <p>Sem problema. Solicite a segunda via com o valor atualizado (incluindo multa e juros de atraso). <strong>Não pague o boleto original vencido</strong>, pois o banco pode recusar ou você pode pagar o valor errado.</p>

  <div class="warning-box">
    <strong>&#9888;&#65039; Cuidado com golpes:</strong> Sempre verifique de quem está recebendo o boleto. Não pague boletos recebidos por fontes desconhecidas. Solicite a segunda via sempre por canais oficiais ou por portais confiáveis como este.
  </div>

  <h2>Como evitar perder o boleto no futuro</h2>
  <ul>
    <li>Mantenha seu e-mail e número de telefone sempre atualizados no cadastro da Unimed;</li>
    <li>Solicite que o boleto seja enviado mensalmente por WhatsApp ou e-mail;</li>
    <li>Configure um lembrete no celular para checar o boleto todo mês;</li>
    <li>Considere o débito automático em conta corrente (se disponível na sua cooperativa);</li>
    <li>Acesse o portal do beneficiário periodicamente para verificar pendências financeiras.</li>
  </ul>

  <div class="article-cta">
    <h3>Precisa de ajuda com seu boleto?</h3>
    <p>Acesse o portal do cliente Unimed e resolva online de forma rápida e segura.</p>
    <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>" class="btn btn-whatsapp btn-lg" target="_blank" rel="noopener noreferrer">Solicitar Segunda Via</a>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
