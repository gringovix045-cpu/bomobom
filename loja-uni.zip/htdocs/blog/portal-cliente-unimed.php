<?php
require_once __DIR__ . '/../includes/config.php';
$page_title       = 'Como Acessar o Portal do Cliente Unimed (e Emitir a Segunda Via)';
$page_description = 'Guia completo para acessar o portal do beneficiário Unimed, emitir a segunda via do boleto online e o que fazer quando não consegue entrar. Atualizado 2025.';
$page_keywords    = 'portal cliente unimed, portal beneficiario unimed, como acessar portal unimed, segunda via boleto portal unimed, portal unimed login';
$breadcrumbs = [
  ['name' => 'Início', 'url' => '/'],
  ['name' => 'Blog',   'url' => '/blog/'],
  ['name' => 'Portal do Cliente Unimed', 'url' => '/blog/portal-cliente-unimed.php'],
];
$schema = '<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Como Acessar o Portal do Cliente Unimed e Emitir a Segunda Via",
  "description": "' . addslashes($page_description) . '",
  "author": {"@type": "Organization", "name": "' . SITE_NAME . '"},
  "publisher": {"@type": "Organization", "name": "' . SITE_NAME . '", "url": "' . SITE_URL . '"},
  "datePublished": "2025-06-01",
  "dateModified": "2025-06-01",
  "mainEntityOfPage": "' . SITE_URL . '/blog/portal-cliente-unimed.php"
}
</script>';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-hero">
  <div class="container">
    <h1>Portal do Cliente Unimed: Como Acessar e Emitir a Segunda Via</h1>
    <p>Guia passo a passo para entrar no portal do beneficiário e emitir a segunda via do boleto — e o que fazer quando não consegue acessar.</p>
  </div>
</div>
<nav class="breadcrumb-nav" aria-label="Breadcrumb">
  <div class="container">
    <a href="/">Início</a> <span>›</span>
    <a href="/blog/">Blog</a> <span>›</span>
    <span aria-current="page">Portal do Cliente Unimed</span>
  </div>
</nav>
<article class="section">
  <div class="container" style="max-width:780px;">

    <div class="blog-meta-bar">
      <span>&#128197; Junho 2025</span>
      <span>&#128336; 5 min de leitura</span>
      <span>&#127991; Portal</span>
    </div>

    <h2>O que é o Portal do Beneficiário Unimed?</h2>
    <p>O Portal do Beneficiário (ou Portal do Cliente) da Unimed é um sistema online onde você pode gerenciar seu plano de saúde. Por ele, é possível emitir a segunda via do boleto, acessar a carteirinha digital, consultar a rede credenciada, verificar autorizações e muito mais.</p>
    <p><strong>Importante:</strong> a Unimed é uma federação de mais de 300 cooperativas regionais. Cada uma tem seu próprio portal — não existe um portal único para toda a Unimed no Brasil.</p>

    <h2>Como acessar o Portal do Cliente Unimed?</h2>
    <p>O passo a passo básico é:</p>
    <ol style="padding-left:1.5rem;line-height:2.2;">
      <li>Acesse o site da Unimed da sua cidade (ex: <em>uninmed.coop.br/suacidade</em>).</li>
      <li>Clique em "Portal do Beneficiário", "Área do Cliente" ou "Minha Unimed".</li>
      <li>Faça login com seu CPF e senha cadastrada.</li>
      <li>Procure a seção "Boletos" ou "Financeiro" e clique em "Segunda Via".</li>
      <li>Faça o download do boleto em PDF ou copie a linha digitável.</li>
    </ol>

    <h2>O que fazer quando não consigo acessar o portal?</h2>
    <p>Os problemas mais comuns e suas soluções:</p>
    <ul style="padding-left:1.5rem;line-height:2.4;">
      <li><strong>Esqueci a senha:</strong> clique em "Esqueci minha senha" e siga as instruções por e-mail ou SMS.</li>
      <li><strong>E-mail/celular desatualizado:</strong> ligue para a central da cooperativa com CPF e dados do contrato.</li>
      <li><strong>Não tenho cadastro:</strong> algumas cooperativas permitem "Primeiro Acesso" com CPF. Verifique no portal.</li>
      <li><strong>Site fora do ar ou lento:</strong> tente novamente depois ou use nosso atendimento pelo WhatsApp — mais rápido!</li>
      <li><strong>CPF não reconhecido:</strong> contate a cooperativa, pode haver divergência no cadastro.</li>
    </ul>

    <h2>Alternativa mais rápida: solicitar a segunda via pelo WhatsApp</h2>
    <p>Se o portal estiver inacessível ou você simplesmente preferir não precisar de senha e login, use nosso atendimento via WhatsApp. É a forma mais simples:</p>
    <ol style="padding-left:1.5rem;line-height:2.2;">
      <li>Clique no botão de WhatsApp abaixo.</li>
      <li>Informe seu nome completo e CPF.</li>
      <li>Receba o boleto atualizado diretamente no chat em minutos.</li>
    </ol>

    <div style="background:var(--primary-light);border-radius:var(--radius-lg);padding:32px;text-align:center;margin-top:40px;">
      <h2 style="font-size:1.2rem;font-weight:800;color:var(--primary);margin-bottom:10px;">Não conseguiu acessar o portal?</h2>
      <p style="color:var(--text-muted);margin-bottom:20px;">Solicite a segunda via pelo WhatsApp agora — sem precisar de senha ou login.</p>
      <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>" class="btn btn-whatsapp" target="_blank" rel="noopener noreferrer">Solicitar Segunda Via</a>
    </div>

    <div style="margin-top:48px;padding-top:32px;border-top:1px solid var(--border);">
      <h3 style="font-size:1rem;font-weight:700;margin-bottom:16px;">&#128196; Artigos Relacionados</h3>
      <ul style="list-style:none;display:flex;flex-direction:column;gap:8px;">
        <li><a href="/como-emitir-segunda-via-boleto-unimed.php">&#10132; Como emitir a segunda via do boleto Unimed pelo celular</a></li>
        <li><a href="/perdi-boleto-unimed.php">&#10132; Perdi o boleto Unimed: o que fazer?</a></li>
        <li><a href="/segunda-via-boleto-unimed-pix.php">&#10132; Como pagar o boleto Unimed pelo PIX</a></li>
      </ul>
    </div>
  </div>
</article>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
