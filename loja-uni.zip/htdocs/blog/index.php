<?php
require_once __DIR__ . '/../includes/config.php';
$page_title       = 'Blog — Segunda Via de Boleto Unimed: Guias e Dicas';
$page_description = 'Artigos completos sobre segunda via de boleto Unimed: como emitir, boleto vencido, pagar pelo PIX, acessar o portal e muito mais. Tudo que você precisa saber.';
$page_keywords    = 'blog segunda via boleto unimed, artigos boleto unimed, como emitir boleto unimed, boleto unimed vencido guia';
$breadcrumbs = [
  ['name' => 'Início', 'url' => '/'],
  ['name' => 'Blog',   'url' => '/blog/'],
];
require_once __DIR__ . '/../includes/header.php';

$posts = [
  [
    'url' => '/blog/como-emitir-segunda-via-boleto-unimed.php',
    'icon'    => '&#128196;',
    'tag'     => 'Segunda Via',
    'title'   => 'Como emitir a segunda via do boleto Unimed pelo celular',
    'excerpt' => 'Passo a passo completo para conseguir a segunda via do boleto Unimed de forma rápida. Veja todos os canais: WhatsApp, portal online e central telefônica.',
    'date'    => 'Jun 2025',
    'time'    => '3 min',
  ],
  [
    'url' => '/blog/boleto-unimed-vencido.php',
    'icon'    => '&#9201;',
    'tag'     => 'Boleto Vencido',
    'title'   => 'Boleto Unimed vencido: posso pagar? O que acontece?',
    'excerpt' => 'Boleto passou da data? Saiba exatamente o que acontece, como atualizar o valor e regularizar sua situação sem perder a cobertura do plano.',
    'date'    => 'Jun 2025',
    'time'    => '4 min',
  ],
  [
    'url' => '/blog/perdi-boleto-unimed.php',
    'icon'    => '&#10067;',
    'tag'     => 'Segunda Via',
    'title'   => 'Perdi o boleto Unimed: o que fazer agora?',
    'excerpt' => 'Perdeu o boleto do plano Unimed? Saiba como solicitar a segunda via rapidamente pelo WhatsApp, portal ou central de atendimento.',
    'date'    => 'Mai 2025',
    'time'    => '3 min',
  ],
  [
    'url' => '/blog/portal-cliente-unimed.php',
    'icon'    => '&#128187;',
    'tag'     => 'Portal',
    'title'   => 'Portal do Cliente Unimed: como acessar e emitir a segunda via',
    'excerpt' => 'Guia completo para acessar o portal do beneficiário Unimed online e emitir a segunda via do boleto. O que fazer quando não consigo entrar.',
    'date'    => 'Jun 2025',
    'time'    => '5 min',
  ],
  [
    'url' => '/blog/segunda-via-boleto-unimed-pix.php',
    'icon'    => '&#128176;',
    'tag'     => 'Pagamento',
    'title'   => 'Como pagar o boleto Unimed pelo PIX — É possível?',
    'excerpt' => 'O boleto Unimed aceita PIX? Descubra como funciona o pagamento, se o QR Code já está disponível na sua regional e quais alternativas usar.',
    'date'    => 'Jun 2025',
    'time'    => '4 min',
  ],
  [
    'url' => '/blog/carencia-unimed.php',
    'icon'    => '&#128197;',
    'tag'     => 'Plano',
    'title'   => 'Carência na Unimed: prazos, regras e como reduzir',
    'excerpt' => 'Entenda o que é carência na Unimed, quais são os prazos por tipo de procedimento e como a portabilidade pode reduzir o tempo de espera.',
    'date'    => 'Abr 2025',
    'time'    => '5 min',
  ],
  [
    'url' => '/blog/cobertura-unimed.php',
    'icon'    => '&#127808;',
    'tag'     => 'Plano',
    'title'   => 'O que a Unimed cobre? Consultas, exames, cirurgias e mais',
    'excerpt' => 'Saiba exatamente o que está incluído na cobertura do seu plano Unimed, o que não é coberto e como acionar o plano para cada tipo de serviço.',
    'date'    => 'Abr 2025',
    'time'    => '5 min',
  ],
  [
    'url' => '/blog/como-funciona-plano-unimed.php',
    'icon'    => '&#127973;',
    'tag'     => 'Plano',
    'title'   => 'Como funciona o plano de saúde Unimed: guia completo',
    'excerpt' => 'Entenda como a Unimed funciona, os tipos de planos disponíveis, como usar a rede credenciada e quais são seus direitos como beneficiário.',
    'date'    => 'Mai 2025',
    'time'    => '6 min',
  ],
];
?>

<div class="page-hero">
  <div class="container">
    <h1>Blog: Segunda Via de Boleto Unimed</h1>
    <p>Guias, dicas e respostas para tudo sobre segunda via de boleto Unimed — do básico ao avançado. Conteúdo atualizado e direto ao ponto.</p>
  </div>
</div>

<nav class="breadcrumb-nav" aria-label="Breadcrumb">
  <div class="container">
    <a href="/">Início</a>
    <span>›</span>
    <span aria-current="page">Blog</span>
  </div>
</nav>

<section class="section">
  <div class="container">
    <div class="blog-grid">
      <?php foreach ($posts as $post): ?>
      <article class="blog-card">
        <div class="blog-card-thumb"><?php echo $post['icon']; ?></div>
        <div class="blog-card-body">
          <span class="blog-card-tag"><?php echo htmlspecialchars($post['tag']); ?></span>
          <h2 style="font-size:1.05rem;font-weight:700;margin-bottom:10px;line-height:1.4;">
            <a href="<?php echo $post['url']; ?>" style="color:var(--text);text-decoration:none;">
              <?php echo htmlspecialchars($post['title']); ?>
            </a>
          </h2>
          <p><?php echo htmlspecialchars($post['excerpt']); ?></p>
          <div class="blog-card-meta">
            <span>&#128197; <?php echo $post['date']; ?></span>
            <span>&#128336; <?php echo $post['time']; ?> de leitura</span>
          </div>
          <a href="<?php echo $post['url']; ?>" class="btn btn-outline" style="margin-top:16px;padding:10px 20px;font-size:.875rem;">Ler Artigo</a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="cta-band">
  <div class="container">
    <h2>Precisa de ajuda com seu boleto?</h2>
    <p>Acesse o portal do cliente e resolva online de forma rápida e segura.</p>
    <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>" class="btn btn-whatsapp btn-lg" target="_blank" rel="noopener noreferrer">Solicitar Segunda Via</a>
  </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
