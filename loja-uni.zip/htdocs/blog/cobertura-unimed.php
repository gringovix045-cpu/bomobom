<?php
require_once __DIR__ . '/../includes/config.php';
$page_title       = 'O que a Unimed Cobre? Consultas, Exames, Cirurgias e Mais';
$page_description = 'Saiba o que está incluído na cobertura do plano de saúde Unimed: consultas, exames, internações, cirurgias, e o que não é coberto pelo plano.';
$schema = '<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "O que a Unimed Cobre? Consultas, Exames, Cirurgias e Mais",
  "description": "Saiba o que está incluído na cobertura do plano de saúde Unimed e o que não é coberto.",
  "datePublished": "2025-04-10",
  "dateModified": "' . date('Y-m-d') . '",
  "author": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"},
  "publisher": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"}
}
</script>';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="article-header">
  <div class="container">
    <nav class="breadcrumb" aria-label="Breadcrumb">
      <a href="/">Início</a> ›
      <a href="/blog/">Blog</a> ›
      <span>O que a Unimed cobre</span>
    </nav>
    <h1>O que a Unimed Cobre? Consultas, Exames, Cirurgias e Mais</h1>
    <div class="article-meta">
      <span>&#128197; 10 de abril de 2025</span>
      <span>&#128336; 5 minutos de leitura</span>
      <span>&#127991; Cobertura</span>
    </div>
  </div>
</div>

<div class="article-body">

  <p>Uma das dúvidas mais comuns entre os beneficiários da Unimed é: <strong>"o meu plano cobre isso?"</strong>. A resposta depende do tipo de plano contratado e do <strong>Rol de Procedimentos da ANS</strong> — a lista mínima obrigatória de cobertura.</p>
  <p>Neste artigo, explicamos o que geralmente está coberto, o que não está e como descobrir o que seu plano específico cobre.</p>

  <h2>O Rol de Procedimentos da ANS</h2>
  <p>A ANS (Agência Nacional de Saúde Suplementar) define um <strong>Rol de Procedimentos e Eventos em Saúde</strong> — a lista mínima obrigatória de cobertura que todos os planos de saúde no Brasil devem oferecer.</p>
  <p>A Unimed, como qualquer operadora regulamentada pela ANS, é obrigada a cobrir todos os procedimentos do Rol. Planos mais completos podem oferecer coberturas adicionais.</p>

  <h2>O que o plano Unimed cobre (geral)</h2>

  <h3>Plano ambulatorial</h3>
  <ul>
    <li>Consultas médicas em todas as especialidades;</li>
    <li>Exames laboratoriais (sangue, urina, etc.);</li>
    <li>Exames de imagem (raio-X, ultrassom, tomografia, ressonância);</li>
    <li>Sessões de fisioterapia, fonoaudiologia e terapia ocupacional;</li>
    <li>Pequenas cirurgias ambulatoriais (sem internação);</li>
    <li>Vacinação (somente as vacinas previstas no Rol da ANS).</li>
  </ul>

  <h3>Plano hospitalar</h3>
  <p>Tudo do ambulatorial, mais:</p>
  <ul>
    <li>Internações hospitalares;</li>
    <li>Cirurgias de médio e grande porte;</li>
    <li>UTI (Unidade de Terapia Intensiva);</li>
    <li>Pronto-socorro 24 horas;</li>
    <li>Hemodiálise e quimioterapia;</li>
    <li>Transplantes previstos no Rol da ANS;</li>
    <li>Acompanhante para crianças e idosos durante internação.</li>
  </ul>

  <h3>Plano com obstetrícia</h3>
  <p>Tudo do hospitalar, mais:</p>
  <ul>
    <li>Parto normal e cesariana;</li>
    <li>Internação da mãe e do bebê;</li>
    <li>Assistência ao recém-nascido por 30 dias após o nascimento;</li>
    <li>Planejamento familiar (vasectomia, laqueadura).</li>
  </ul>

  <h2>O que a Unimed geralmente NÃO cobre</h2>
  <div class="warning-box">
    <strong>&#9888;&#65039; Atenção:</strong> A lista abaixo representa exclusões comuns, mas o seu contrato específico pode ter variações. Sempre consulte o contrato ou fale com a Unimed para confirmar.
  </div>
  <ul>
    <li>Cirurgias plásticas exclusivamente estéticas (sem indicação médica);</li>
    <li>Tratamentos experimentais não reconhecidos pelo CFM ou ANS;</li>
    <li>Medicamentos para uso domiciliar (exceto os previstos no Rol);</li>
    <li>Óculos e lentes de contato;</li>
    <li>Aparelhos ortodônticos (exceto em planos odontológicos);</li>
    <li>Tratamentos de fertilização in vitro (em muitos planos);</li>
    <li>Internação em clínicas de repouso ou SPAs;</li>
    <li>Tratamento de lesões causadas por atos criminosos (roubo, etc.) — exceto urgências.</li>
  </ul>

  <h2>Como descobrir se um procedimento específico é coberto?</h2>
  <p>Para confirmar se determinado procedimento está coberto no seu plano, você pode:</p>
  <ol>
    <li>Consultar o <strong>Rol de Procedimentos da ANS</strong> (disponível no site da ANS);</li>
    <li>Ligar para a central de atendimento da sua cooperativa Unimed;</li>
    <li>Verificar no portal ou app do beneficiário;</li>
    <li>Falar com nossa equipe pelo WhatsApp para orientação.</li>
  </ol>

  <div class="info-box">
    <strong>&#128161; Recusa de cobertura:</strong> Se a Unimed negar cobertura para um procedimento que você acredita estar coberto, você pode registrar reclamação na ANS pelo telefone <strong>0800 701 9656</strong> ou pelo site da ANS.
  </div>

  <div class="article-cta">
    <h3>Precisa de ajuda com seu boleto?</h3>
    <p>Acesse o portal do cliente Unimed e resolva online de forma rápida e segura.</p>
    <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>" class="btn btn-whatsapp btn-lg" target="_blank" rel="noopener noreferrer">Solicitar Segunda Via</a>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
