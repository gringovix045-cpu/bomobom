<?php
require_once __DIR__ . '/../includes/config.php';
$page_title       = 'Como Funciona o Plano de Saúde Unimed: Guia Completo';
$page_description = 'Entenda como funciona o plano de saúde Unimed: tipos de planos, cobertura, carência, rede credenciada, boleto e seus direitos como beneficiário.';
$schema = '<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Como Funciona o Plano de Saúde Unimed: Guia Completo",
  "description": "Entenda como funciona o plano de saúde Unimed: tipos de planos, cobertura, carência e rede credenciada.",
  "datePublished": "2025-05-15",
  "dateModified": "' . date('Y-m-d') . '",
  "author": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"},
  "publisher": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"}
}
</script>';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="article-header">
  <div class="container">
    <nav class="breadcrumb" aria-label="Breadcrumb">
      <a href="/">Início</a> ›
      <a href="/blog/">Blog</a> ›
      <span>Como funciona o plano Unimed</span>
    </nav>
    <h1>Como Funciona o Plano de Saúde Unimed: Guia Completo</h1>
    <div class="article-meta">
      <span>&#128197; 15 de maio de 2025</span>
      <span>&#128336; 6 minutos de leitura</span>
      <span>&#127991; Plano de Saúde</span>
    </div>
  </div>
</div>

<div class="article-body">

  <p>A <strong>Unimed</strong> é a maior cooperativa médica do Brasil e um dos principais planos de saúde do país. Mas apesar de ser tão popular, muitos beneficiários têm dúvidas sobre como o plano funciona na prática.</p>
  <p>Neste guia completo, explicamos tudo de forma simples e direta — para que você aproveite ao máximo o seu plano.</p>

  <h2>O que é a Unimed?</h2>
  <p>A Unimed não é uma empresa única, mas sim um <strong>sistema de cooperativas médicas</strong>. Cada cidade ou região pode ter sua própria cooperativa Unimed, com médicos cooperados que são donos do negócio.</p>
  <p>Isso significa que o plano Unimed de São Paulo pode ser diferente do de Belo Horizonte, por exemplo. Cada cooperativa tem sua própria rede de médicos, hospitais e condições de contratação.</p>

  <h2>Tipos de planos Unimed</h2>
  <p>A Unimed oferece diferentes tipos de planos, classificados pela ANS:</p>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Tipo</th><th>O que cobre</th></tr>
      </thead>
      <tbody>
        <tr><td><strong>Ambulatorial</strong></td><td>Consultas médicas, exames laboratoriais e de imagem, pequenas cirurgias ambulatoriais</td></tr>
        <tr><td><strong>Hospitalar sem obstetrícia</strong></td><td>Internações, cirurgias, UTI, pronto-socorro (sem cobertura para parto)</td></tr>
        <tr><td><strong>Hospitalar com obstetrícia</strong></td><td>Tudo do hospitalar + partos (normal e cesárea)</td></tr>
        <tr><td><strong>Referência</strong></td><td>Cobertura mínima obrigatória pela ANS, ambulatorial + hospitalar com obstetrícia</td></tr>
      </tbody>
    </table>
  </div>

  <h2>Como funciona o pagamento do plano?</h2>
  <p>O beneficiário paga uma <strong>mensalidade</strong> (o boleto que chegou até você). Em contratos coletivos empresariais, parte ou todo o valor pode ser pago pela empresa empregadora.</p>
  <p>Geralmente, o boleto vence todo mês numa data fixada no contrato (ex.: dia 10 de cada mês). O não pagamento pode levar à suspensão e eventual cancelamento do plano.</p>

  <h2>Como usar o plano Unimed</h2>
  <p>Para usar o plano, o processo básico é:</p>
  <ol>
    <li>Verifique sua <strong>carteirinha Unimed</strong> ou o número do plano;</li>
    <li>Escolha um médico ou serviço dentro da <strong>rede credenciada</strong> da Unimed;</li>
    <li>Na consulta ou exame, apresente o cartão/carteirinha Unimed;</li>
    <li>Para internações, entre em contato com a Unimed para autorização prévia quando necessário.</li>
  </ol>

  <h2>O que é a rede credenciada?</h2>
  <p>A rede credenciada é o conjunto de médicos, clínicas, laboratórios e hospitais que têm contrato com a Unimed para atender seus beneficiários. Consultar médicos <strong>dentro da rede</strong> garante que os custos sejam cobertos pelo plano.</p>
  <p>Atendimentos fora da rede credenciada geralmente <strong>não são cobertos</strong>, exceto em casos de urgência/emergência ou quando não há profissional da especialidade na rede local.</p>

  <h2>Reajuste do plano</h2>
  <p>Os planos de saúde são reajustados anualmente. Para planos individuais e familiares, a ANS define o percentual máximo de reajuste. Para planos coletivos, o reajuste é negociado entre a operadora e a empresa contratante.</p>

  <div class="info-box">
    <strong>&#128161; Direito do beneficiário:</strong> Você deve ser notificado com pelo menos 30 dias de antecedência sobre qualquer reajuste no valor do plano.
  </div>

  <h2>O que fazer em caso de urgência ou emergência?</h2>
  <p>Em situações de urgência (risco de agravamento) ou emergência (risco de vida), a Unimed <strong>deve garantir atendimento desde o primeiro dia do plano</strong>, independentemente de carência. Procure o pronto-socorro da rede credenciada mais próximo.</p>

  <div class="article-cta">
    <h3>Precisa de ajuda com seu boleto?</h3>
    <p>Acesse o portal do cliente Unimed e resolva online de forma rápida e segura.</p>
    <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>" class="btn btn-whatsapp btn-lg" target="_blank" rel="noopener noreferrer">Solicitar Segunda Via</a>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
