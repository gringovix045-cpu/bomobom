<?php
require_once __DIR__ . '/../includes/config.php';
$page_title       = 'Boleto Unimed Vencido: posso pagar? O que acontece?';
$page_description = 'Boleto Unimed vencido? Saiba o que acontece, se você pode pagar, como atualizar o valor e evitar o cancelamento do plano. Tire todas suas dúvidas aqui.';
$schema = '<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Boleto Unimed Vencido: posso pagar? O que acontece?",
  "description": "Saiba o que acontece com o boleto Unimed vencido, se você pode pagar e como regularizar sua situação.",
  "datePublished": "2025-06-02",
  "dateModified": "' . date('Y-m-d') . '",
  "author": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"},
  "publisher": {"@type":"Organization","name":"' . SITE_NAME . '","url":"' . SITE_URL . '"}
}
</script>';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="article-header">
  <div class="container">
    <nav class="breadcrumb" aria-label="Breadcrumb">
      <a href="/">Início</a> ›
      <a href="/blog/">Blog</a> ›
      <span>Boleto Unimed Vencido</span>
    </nav>
    <h1>Boleto Unimed Vencido: posso pagar? O que acontece?</h1>
    <div class="article-meta">
      <span>&#128197; 2 de junho de 2025</span>
      <span>&#128336; 4 minutos de leitura</span>
      <span>&#127991; Boleto e Pagamento</span>
    </div>
  </div>
</div>

<div class="article-body">

  <p>Passar da data de vencimento do boleto do plano de saúde é uma situação que pode causar muita preocupação. Afinal, você vai perder a cobertura? O valor vai aumentar muito? Ainda dá pra pagar?</p>
  <p>Calma! Neste artigo, respondemos todas essas dúvidas de forma clara e objetiva.</p>

  <h2>Posso pagar um boleto Unimed vencido?</h2>
  <p>A resposta curta é: <strong>depende de quantos dias se passaram</strong>.</p>
  <ul>
    <li><strong>Vencido há menos de 3 dias:</strong> Na maioria dos casos, você ainda consegue pagar em lotéricas, caixas de banco ou aplicativos de internet banking. Porém, pode haver cobrança de multa e juros.</li>
    <li><strong>Vencido há mais de 3 dias:</strong> Os sistemas bancários geralmente rejeitam o pagamento. Você precisará solicitar uma <strong>segunda via atualizada</strong> com os novos valores.</li>
  </ul>

  <div class="warning-box">
    <strong>&#9888;&#65039; Nunca pague um boleto vencido sem confirmar os valores:</strong> O código de barras do boleto original não é atualizado automaticamente. Se você tentar pagar o valor original de um boleto vencido, o banco pode rejeitar a transação ou você pode pagar o valor incorreto.
  </div>

  <h2>O que acontece com o meu plano se o boleto vencer?</h2>
  <p>A ANS (Agência Nacional de Saúde Suplementar) estabelece regras claras sobre o que as operadoras podem fazer em caso de inadimplência:</p>
  <ol>
    <li><strong>Até 30 dias:</strong> A operadora não pode suspender ou cancelar o plano nesse período.</li>
    <li><strong>Entre 30 e 60 dias:</strong> A operadora pode notificá-lo sobre a inadimplência e o risco de suspensão.</li>
    <li><strong>Após 60 dias de inadimplência:</strong> O plano pode ser suspenso. Após notificação formal, pode ser cancelado.</li>
  </ol>
  <p>No entanto, <strong>em casos de urgência e emergência, o atendimento deve ser garantido</strong> mesmo com plano suspenso por inadimplência, por até 30 dias após a suspensão.</p>

  <h2>Quais encargos são cobrados no boleto vencido?</h2>
  <p>Os encargos por atraso variam conforme o contrato do seu plano, mas em geral são:</p>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Encargo</th><th>Valor Típico</th><th>Observação</th></tr>
      </thead>
      <tbody>
        <tr><td>Multa por atraso</td><td>2% sobre o valor</td><td>Cobrada uma única vez</td></tr>
        <tr><td>Juros de mora</td><td>1% ao mês (0,033% ao dia)</td><td>Proporcional aos dias de atraso</td></tr>
      </tbody>
    </table>
  </div>
  <p>Exemplo: boleto de R$ 500,00 com 15 dias de atraso = R$ 500 + R$ 10 (multa 2%) + R$ 2,50 (juros 0,5%) = <strong>R$ 512,50</strong>.</p>

  <h2>Como pagar um boleto Unimed vencido?</h2>
  <p>O caminho correto é:</p>
  <ol>
    <li>Solicite uma <strong>segunda via atualizada</strong> pelo nosso WhatsApp;</li>
    <li>Receba o novo boleto com os encargos calculados;</li>
    <li>Pague o boleto atualizado normalmente em qualquer banco ou lotérica.</li>
  </ol>
  <p>Não tente pagar o boleto original vencido — solicite sempre um novo com valores atualizados.</p>

  <h2>Meu plano foi suspenso por falta de pagamento. E agora?</h2>
  <p>Se seu plano foi suspenso, siga estes passos:</p>
  <ol>
    <li>Regularize todos os boletos em aberto (solicite a segunda via atualizada);</li>
    <li>Após o pagamento, guarde os comprovantes;</li>
    <li>Entre em contato com a Unimed para informar o pagamento e solicitar a reativação;</li>
    <li>Aguarde o prazo de reativação (geralmente 1 a 3 dias úteis).</li>
  </ol>

  <div class="info-box">
    <strong>&#128161; Dica importante:</strong> Conforme a ANS, a operadora deve reativar o plano em prazo razoável após a confirmação do pagamento. Se isso não ocorrer, você pode registrar uma reclamação na ANS pelo telefone 0800 701 9656.
  </div>

  <h2>Como evitar o vencimento do boleto no futuro?</h2>
  <ul>
    <li>Configure lembretes no calendário do seu celular com antecedência;</li>
    <li>Solicite o envio do boleto por e-mail ou WhatsApp todo mês;</li>
    <li>Verifique se seu e-mail cadastrado na Unimed está atualizado;</li>
    <li>Considere o débito automático em conta bancária (se sua cooperativa oferecer).</li>
  </ul>

  <div class="article-cta">
    <h3>Precisa de ajuda com seu boleto?</h3>
    <p>Acesse o portal do cliente Unimed e resolva online de forma rápida e segura.</p>
    <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode(WHATSAPP_MESSAGE); ?>" class="btn btn-whatsapp btn-lg" target="_blank" rel="noopener noreferrer">Solicitar Segunda Via</a>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
